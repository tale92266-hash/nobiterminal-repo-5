#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MonetDB::bat" for configuration "Release"
set_property(TARGET MonetDB::bat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MonetDB::bat PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "MonetDB::stream;MonetDB::mutils"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libbat-11.55.9.so"
  IMPORTED_SONAME_RELEASE "libbat-11.55.9.so"
  )

list(APPEND _cmake_import_check_targets MonetDB::bat )
list(APPEND _cmake_import_check_files_for_MonetDB::bat "/data/data/com.nobiterminal/files/usr/lib/libbat-11.55.9.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
