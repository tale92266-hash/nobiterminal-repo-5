#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MonetDB::monetdbe" for configuration "Release"
set_property(TARGET MonetDB::monetdbe APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MonetDB::monetdbe PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "MonetDB::mapi;MonetDB::stream;MonetDB::bat;MonetDB::monetdb5;MonetDB::sql;MonetDB::mutils"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libmonetdbe.so"
  IMPORTED_SONAME_RELEASE "libmonetdbe.so"
  )

list(APPEND _cmake_import_check_targets MonetDB::monetdbe )
list(APPEND _cmake_import_check_files_for_MonetDB::monetdbe "/data/data/com.nobiterminal/files/usr/lib/libmonetdbe.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
