#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MonetDB::sql" for configuration "Release"
set_property(TARGET MonetDB::sql APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MonetDB::sql PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "MonetDB::monetdb5;MonetDB::mapi;MonetDB::bat;MonetDB::mutils"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libmonetdbsql-11.55.9.so"
  IMPORTED_SONAME_RELEASE "libmonetdbsql-11.55.9.so"
  )

list(APPEND _cmake_import_check_targets MonetDB::sql )
list(APPEND _cmake_import_check_files_for_MonetDB::sql "/data/data/com.nobiterminal/files/usr/lib/libmonetdbsql-11.55.9.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
