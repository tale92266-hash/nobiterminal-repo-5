#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MonetDB::monetdb5" for configuration "Release"
set_property(TARGET MonetDB::monetdb5 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MonetDB::monetdb5 PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "MonetDB::stream;MonetDB::mapi;MonetDB::mutils;MonetDB::bat"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libmonetdb5-11.55.9.so"
  IMPORTED_SONAME_RELEASE "libmonetdb5-11.55.9.so"
  )

list(APPEND _cmake_import_check_targets MonetDB::monetdb5 )
list(APPEND _cmake_import_check_files_for_MonetDB::monetdb5 "/data/data/com.nobiterminal/files/usr/lib/libmonetdb5-11.55.9.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
