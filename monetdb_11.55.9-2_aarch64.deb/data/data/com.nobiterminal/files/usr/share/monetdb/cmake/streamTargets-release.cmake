#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MonetDB::stream" for configuration "Release"
set_property(TARGET MonetDB::stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MonetDB::stream PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "MonetDB::mutils"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libstream-11.55.9.so"
  IMPORTED_SONAME_RELEASE "libstream-11.55.9.so"
  )

list(APPEND _cmake_import_check_targets MonetDB::stream )
list(APPEND _cmake_import_check_files_for_MonetDB::stream "/data/data/com.nobiterminal/files/usr/lib/libstream-11.55.9.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
