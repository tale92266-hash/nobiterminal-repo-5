{application, 'rabbitmq_amqp1_0', [
	{description, "Deprecated no-op AMQP 1.0 plugin"},
	{vsn, "4.4.0"},
	{id, "24d5157"},
	{modules, ['rabbitmq_amqp1_0_noop']},
	{registered, []},
	{applications, [kernel,stdlib,rabbit]},
	{optional_applications, []},
	{env, []}
]}.