{application,cuttlefish,
             [{description,"cuttlefish configuration abstraction"},
              {vsn,"3.9.1"},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {env,[]},
              {licenses,["Apache-2.0"]},
              {links,[{"GitHub","https://github.com/Kyorai/cuttlefish"}]},
              {modules, ['conf_parse','cuttlefish','cuttlefish_advanced','cuttlefish_bytesize','cuttlefish_conf','cuttlefish_datatypes','cuttlefish_diff','cuttlefish_duration','cuttlefish_duration_parse','cuttlefish_effective','cuttlefish_enum','cuttlefish_error','cuttlefish_escript','cuttlefish_flag','cuttlefish_generator','cuttlefish_mapping','cuttlefish_partial','cuttlefish_paths','cuttlefish_rebar_plugin','cuttlefish_schema','cuttlefish_translation','cuttlefish_unit','cuttlefish_util','cuttlefish_validator','cuttlefish_variable','cuttlefish_vmargs']}]}.
