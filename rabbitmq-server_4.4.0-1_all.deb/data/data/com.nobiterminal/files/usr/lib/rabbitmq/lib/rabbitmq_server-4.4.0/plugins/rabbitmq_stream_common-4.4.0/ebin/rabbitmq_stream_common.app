{application, 'rabbitmq_stream_common', [
	{description, "RabbitMQ Stream Common"},
	{vsn, "4.4.0"},
	{id, "24d5157"},
	{modules, ['rabbit_stream_core']},
	{registered, []},
	{applications, [kernel,stdlib,osiris]},
	{optional_applications, []},
	{env, [
]}
]}.