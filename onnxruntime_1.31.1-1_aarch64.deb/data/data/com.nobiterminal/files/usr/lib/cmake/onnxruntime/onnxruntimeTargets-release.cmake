#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "onnxruntime::onnxruntime" for configuration "Release"
set_property(TARGET onnxruntime::onnxruntime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnxruntime::onnxruntime PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "re2::re2;absl::synchronization;absl::tracing_internal;absl::time;absl::time_zone;absl::civil_time;absl::symbolize;absl::demangle_internal;absl::demangle_rust;absl::stacktrace;absl::debugging_internal;absl::malloc_internal;absl::kernel_timeout_internal;absl::graphcycles_internal;absl::str_format_internal;absl::raw_hash_set;absl::hashtablez_sampler;absl::cord;absl::crc_cord_state;absl::crc32c;absl::cordz_info;absl::cordz_functions;absl::cord_internal;absl::hash;absl::strings;absl::strings_internal;absl::int128;absl::city;absl::throw_delegate;absl::base;absl::spinlock_wait;absl::raw_logging_internal;absl::log_severity"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libonnxruntime.so"
  IMPORTED_SONAME_RELEASE "libonnxruntime.so"
  )

list(APPEND _cmake_import_check_targets onnxruntime::onnxruntime )
list(APPEND _cmake_import_check_files_for_onnxruntime::onnxruntime "${_IMPORT_PREFIX}/lib/libonnxruntime.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
