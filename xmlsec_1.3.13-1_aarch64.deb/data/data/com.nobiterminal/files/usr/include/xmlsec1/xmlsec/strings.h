/**
 * XML Security Library (http://www.aleksey.com/xmlsec).
 *
 * This is free software; see the Copyright file in the source distribution for precise wording.
 *
 * Copyright (C) 2002-2026 Aleksey Sanin <aleksey@aleksey.com>. All Rights Reserved.
 */
#ifndef XMLSEC_STRINGS_H
#define XMLSEC_STRINGS_H

/**
 * @brief XMLDSig/XMLEnc string constants.
 * @details XMLDSig/XMLEnc string constants. These are internal XMLSec library constants
 * and are specifically excluded from the external documentation.
 */

#include <libxml/tree.h>

#include <xmlsec/exports.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/******************************************************************************
 *
 * Global Namespaces
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecDSigNs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecDSig11Ns[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecEncNs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecEnc11Ns[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecXPathNs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecXPath2Ns[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecXPointerNs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecDSig2021MoreNs[];

/** @brief Deprecated. Use xmlSecDSig2021MoreNs instead. */
#define xmlSecXmldsig2021MoreNs  xmlSecDSig2021MoreNs


/******************************************************************************
 *
 * DSig Nodes
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSignature[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSignedInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSignatureValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeCanonicalizationMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSignatureMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDigestMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDigestValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeObject[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeManifest[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSignatureProperties[];

/******************************************************************************
 *
 * Encryption Nodes
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEncryptedData[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEncryptionMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEncryptionProperties[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEncryptionProperty[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeCipherData[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeCipherValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeCipherReference[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeReferenceList[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDataReference[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKeyReference[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeCarriedKeyName[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecTypeEncContent[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecTypeEncElement[];

/******************************************************************************
 *
 * KeyInfo and Transform Nodes
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKeyInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeReference[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeTransforms[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeTransform[];

/******************************************************************************
 *
 * Attributes
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrId[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrURI[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrType[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrMimeType[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrEncoding[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrAlgorithm[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrTarget[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrFilter[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrRecipient[];

/******************************************************************************
 *
 * AES strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAESKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeAESKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAESKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAes128Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAes128Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAes192Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAes192Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAes256Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAes256Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAes128Gcm[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAes128Gcm[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAes192Gcm[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAes192Gcm[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAes256Gcm[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAes256Gcm[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWAes128[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWAes128[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWAes192[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWAes192[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWAes256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWAes256[];

/******************************************************************************
 *
 * Camellia strings
 *
  *****************************************************************************/
#ifndef XMLSEC_NO_CAMELLIA
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameCamelliaKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeCamelliaKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefCamelliaKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameCamellia128Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefCamellia128Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameCamellia192Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefCamellia192Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameCamellia256Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefCamellia256Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWCamellia128[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWCamellia128[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWCamellia192[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWCamellia192[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWCamellia256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWCamellia256[];
#endif /* XMLSEC_NO_CAMELLIA */

/******************************************************************************
 *
 * ChaCha20 strings
 *
  *****************************************************************************/
#ifndef XMLSEC_NO_CHACHA20
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameChaCha20[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefChaCha20[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeChaCha20Nonce[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeChaCha20Counter[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameChaCha20KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeChaCha20KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefChaCha20KeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameChaCha20Poly1305[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefChaCha20Poly1305[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeChaCha20Poly1305AAD[];
#endif /* XMLSEC_NO_CHACHA20 */

/******************************************************************************
 *
 * BASE64 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameBase64[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefBase64[];

/******************************************************************************
 *
 * C14N strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameC14N[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefC14N[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameC14NWithComments[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefC14NWithComments[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameC14N11[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefC14N11[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameC14N11WithComments[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefC14N11WithComments[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameExcC14N[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefExcC14N[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameExcC14NWithComments[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefExcC14NWithComments[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNsExcC14N[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNsExcC14NWithComments[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeInclusiveNamespaces[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrPrefixList[];

/******************************************************************************
 *
 * ConcatKDF strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameConcatKdfKey[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameConcatKdf[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefConcatKdf[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeConcatKDFParams[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrConcatKDFAlgorithmID[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrConcatKDFPartyUInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrConcatKDFPartyVInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrConcatKDFSuppPubInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecAttrConcatKDFSuppPrivInfo[];

/** @brief Deprecated. Use xmlSecAttrConcatKDFAlgorithmID instead. */
#define xmlSecNodeConcatKDFAttrAlgorithmID  xmlSecAttrConcatKDFAlgorithmID

/** @brief Deprecated. Use xmlSecAttrConcatKDFPartyUInfo instead. */
#define xmlSecNodeConcatKDFAttrPartyUInfo   xmlSecAttrConcatKDFPartyUInfo

/** @brief Deprecated. Use xmlSecAttrConcatKDFPartyVInfo instead. */
#define xmlSecNodeConcatKDFAttrPartyVInfo   xmlSecAttrConcatKDFPartyVInfo

/** @brief Deprecated. Use xmlSecAttrConcatKDFSuppPubInfo instead. */
#define xmlSecNodeConcatKDFAttrSuppPubInfo  xmlSecAttrConcatKDFSuppPubInfo

/** @brief Deprecated. Use xmlSecAttrConcatKDFSuppPrivInfo instead. */
#define xmlSecNodeConcatKDFAttrSuppPrivInfo xmlSecAttrConcatKDFSuppPrivInfo


/******************************************************************************
 *
 * DEREncodedKeyValue strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDEREncodedKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDEREncodedKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDEREncodedKeyValue[];

/******************************************************************************
 *
 * DES strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDESKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDESKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDESKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDes3Cbc[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDes3Cbc[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKWDes3[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefKWDes3[];

/******************************************************************************
 *
 * DH key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDHKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDHKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHP[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHQ[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHGenerator[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHPublic[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHSeed[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDHPgenCounter[];

/******************************************************************************
 *
 * DH-ES key agreement strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDhEs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDhEs[];

/******************************************************************************
 *
 * DSA strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDSAKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAP[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAQ[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAG[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAJ[];
/* DSA X node is proprietary extension by XMLSec library and uses xmlSecNs namespace.
 * DEPRECATED and will be removed in the future. */
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAX[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAY[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSASeed[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDSAPgenCounter[];


XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDsaSha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDsaSha1[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDsaSha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDsaSha256[];

/******************************************************************************
 *
 * EC key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameECKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeECKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefECKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeNamedCurve[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePublicKey[];

/******************************************************************************
 *
 * ECDH key agreement strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdh[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdh[];

/******************************************************************************
 *
 * X25519 key agreement strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameX25519[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefX25519[];

/******************************************************************************
 *
 * X448 key agreement strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameX448[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefX448[];

/******************************************************************************
 *
 * XDH key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameXDHKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefXDHKeyValue[];

/******************************************************************************
 *
 * ECDSA signature strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaRipemd160[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaRipemd160[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha1[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha512[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha3_224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha3_224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha3_256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha3_256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha3_384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha3_384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEcdsaSha3_512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEcdsaSha3_512[];

/******************************************************************************
 *
 * GOST2001 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGOST2001KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeGOST2001KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGOST2001KeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGost2001GostR3411_94[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGost2001GostR3411_94[];

/******************************************************************************
 *
 * GOST R 34.10-2012 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3410_2012_256KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeGostR3410_2012_256KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3410_2012_256KeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3410_2012_512KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeGostR3410_2012_512KeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3410_2012_512KeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3410_2012GostR3411_2012_256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3410_2012GostR3411_2012_256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3410_2012GostR3411_2012_512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3410_2012GostR3411_2012_512[];

/******************************************************************************
 *
 * ML-DSA key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLDSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLDSAKeyValue[];

/******************************************************************************
 *
 * ML-DSA signature transform strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecMLDSANs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeMLDSAContextString[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLDSA44[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLDSA44[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLDSA65[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLDSA65[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLDSA87[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLDSA87[];

/******************************************************************************
 *
 * ML-KEM key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLKEMKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLKEMKeyValue[];

/******************************************************************************
 *
 * ML-KEM key transport transform strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLKEM512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLKEM512[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLKEM768[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLKEM768[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMLKEM1024[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMLKEM1024[];

/******************************************************************************
 *
 * SLH-DSA key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSAKeyValue[];

/******************************************************************************
 *
 * SLH-DSA signature transform strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecSLHDSANs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSLHDSAContextString[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSA_SHA2_128f[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSA_SHA2_128f[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSA_SHA2_128s[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSA_SHA2_128s[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSA_SHA2_192f[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSA_SHA2_192f[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSA_SHA2_192s[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSA_SHA2_192s[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSA_SHA2_256f[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSA_SHA2_256f[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSLHDSA_SHA2_256s[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSLHDSA_SHA2_256s[];


/******************************************************************************
 *
 * EdDSA key strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEdDSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEdDSAKeyValue[];

/******************************************************************************
 *
 * EdDSA signature transform strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecEdDSANs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEdDSAContextString[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEdDSAEd25519[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEdDSAEd25519[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEdDSAEd25519ctx[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEdDSAEd25519ctx[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEdDSAEd25519ph[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEdDSAEd25519ph[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEdDSAEd448[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEdDSAEd448[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEdDSAEd448ph[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEdDSAEd448ph[];


/******************************************************************************
 *
 * EncryptedKey
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEncryptedKey[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEncryptedKey[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEncryptedKey[];

/******************************************************************************
 *
 * DerivedKey
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameDerivedKey[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDerivedKey[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefDerivedKey[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKeyDerivationMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeDerivedKeyName[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeMasterKeyName[];

/******************************************************************************
 *
 * AgreementMethod
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameAgreementMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeAgreementMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefAgreementMethod[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeOriginatorKeyInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRecipientKeyInfo[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKANonce[];

/******************************************************************************
 *
 * EncapsulationMechanism
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecExperimental202512Ns[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEncapsulationMechanism[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeEncapsulationMechanism[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEncapsulationMechanism[];



/******************************************************************************
 *
 * Enveloped transform strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameEnveloped[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefEnveloped[];

/******************************************************************************
 *
 * HMAC strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHMACKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHMACKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHMACKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHMACOutputLength[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacMd5[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacMd5[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacRipemd160[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacRipemd160[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacSha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacSha1[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacSha224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacSha224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacSha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacSha256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacSha384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacSha384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHmacSha512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHmacSha512[];


/******************************************************************************
 *
 * KeyInfoReference
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKeyInfoReference[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKeyInfoReference[];

/******************************************************************************
 *
 * KeyName strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKeyName[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKeyName[];

/******************************************************************************
 *
 * KeyValue strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeKeyValue[];

/******************************************************************************
 *
 * Memory Buffer strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMemBuf[];

/******************************************************************************
 *
 * MD5 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameMd5[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMd5[];

/******************************************************************************
 *
 * PBKDF2 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNamePbkdf2Key[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNamePbkdf2[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefPbkdf2[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePbkdf2Params[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePbkdf2Salt[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePbkdf2SaltSpecified[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePbkdf2IterationCount[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePbkdf2KeyLength[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePbkdf2PRF[];

/******************************************************************************
 *
 * HKDF strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHkdfKey[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameHkdf[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefHkdf[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHkdfParams[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHkdfPRF[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHkdfSalt[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHkdfInfo[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeHkdfKeyLength[];


/******************************************************************************
 *
 * RetrievalMethod
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRetrievalMethod[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRetrievalMethod[];

/******************************************************************************
 *
 * RIPEMD160 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRipemd160[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRipemd160[];

/******************************************************************************
 *
 * RSA strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRSAKeyValue[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRSAKeyValue[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRSAModulus[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRSAExponent[];
/* PrivateExponent node is proprietary extension by XMLSec library and uses xmlSecNs namespace.
 * DEPRECATED and will be removed in the future. */
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRSAPrivateExponent[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaMd5[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaMd5[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaRipemd160[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaRipemd160[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaSha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaSha1[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaSha224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaSha224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaSha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaSha256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaSha384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaSha384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaSha512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaSha512[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPkcs1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPkcs1[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaOaep[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaOaep[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaOaepEnc11[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaOaepEnc11[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRsaOAEPparams[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRsaMGF[];

/* MGF1 urls (https://www.w3.org/TR/xmlenc-core1/#sec-RSA-OAEP) */
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMgf1Sha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMgf1Sha224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMgf1Sha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMgf1Sha384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefMgf1Sha512[];


/* RSA PSS https://www.rfc-editor.org/rfc/rfc9231.txt */
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha1[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha512[];


XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha3_224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha3_224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha3_256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha3_256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha3_384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha3_384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRsaPssSha3_512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRsaPssSha3_512[];

/******************************************************************************
 *
 * GOSTR3411_94 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3411_94[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3411_94[];

/******************************************************************************
 *
 * GOST R 34.11-2012 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3411_2012_256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3411_2012_256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameGostR3411_2012_512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefGostR3411_2012_512[];

/******************************************************************************
 *
 * SHA1 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha1[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha1[];

/******************************************************************************
 *
 * SHA2 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha512[];

/******************************************************************************
 *
 * SHA3 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha3_224[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha3_224[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha3_256[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha3_256[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha3_384[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha3_384[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSha3_512[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSha3_512[];


/******************************************************************************
 *
 * X509 strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameX509Data[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509Data[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefX509Data[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509Certificate[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509CRL[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509SubjectName[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509IssuerSerial[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509IssuerName[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509SerialNumber[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509SKI[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeX509Digest[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRawX509Cert[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRawX509Cert[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameX509Store[];

/******************************************************************************
 *
 * DEPRECATED PGP strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNamePGPData[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodePGPData[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefPGPData[];

/******************************************************************************
 *
 * SPKI strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameSPKIData[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeSPKIData[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefSPKIData[];

/******************************************************************************
 *
 * XPath/XPointer strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameXPath[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeXPath[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecNameXPath2[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeXPath2[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecXPath2FilterIntersect[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecXPath2FilterSubtract[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecXPath2FilterUnion[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameXPointer[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeXPointer[];

/******************************************************************************
 *
 * RelationshipTransform strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameRelationship[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefRelationship[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRelationship[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecNodeRelationshipReference[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecRelationshipsNs[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecRelationshipReferenceNs[];

XMLSEC_EXPORT_VAR const xmlChar xmlSecRelationshipAttrId[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecRelationshipAttrSourceId[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecRelationshipAttrTargetMode[];

/******************************************************************************
 *
 * XSLT strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecNameXslt[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecHrefXslt[];

/******************************************************************************
 *
 * Utility strings
 *
  *****************************************************************************/
XMLSEC_EXPORT_VAR const xmlChar xmlSecStringEmpty[];
XMLSEC_EXPORT_VAR const xmlChar xmlSecStringCR[]; /* DEPRECATED */
XMLSEC_EXPORT_VAR const xmlChar xmlSecStringLF[];

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* XMLSEC_STRINGS_H */
