/**
 * XML Security Library (http://www.aleksey.com/xmlsec).
 *
 * This is free software; see the Copyright file in the source distribution for precise wording.
 *
 * Copyright (C) 2002-2026 Aleksey Sanin <aleksey@aleksey.com>. All Rights Reserved.
 * Copyright (c) 2003 America Online, Inc.  All rights reserved.
 */
#ifndef XMLSEC_NSS_APP_H
#define XMLSEC_NSS_APP_H

/**
 * @defgroup xmlsec_nss_app NSS Application Helpers
 * @ingroup xmlsec_nss
 * @brief High-level application helpers for the NSS back-end.
 * @{
 */

#include <nspr.h>
#include <nss.h>

#include <xmlsec/exports.h>
#include <xmlsec/xmlsec.h>
#include <xmlsec/keys.h>
#include <xmlsec/keysmngr.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/******************************************************************************
 *
 * Init/shutdown
 *
  *****************************************************************************/
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppInit                (const char* config);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppShutdown            (void);

/******************************************************************************
 *
 * Keys Manager
 *
  *****************************************************************************/
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppDefaultKeysMngrInit (xmlSecKeysMngrPtr mngr);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppDefaultKeysMngrAdoptKey (xmlSecKeysMngrPtr mngr,
                                                                         xmlSecKeyPtr key);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppDefaultKeysMngrVerifyKey (xmlSecKeysMngrPtr mngr,
                                                                         xmlSecKeyPtr key,
                                                                         xmlSecKeyInfoCtxPtr keyInfoCtx);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppDefaultKeysMngrLoad (xmlSecKeysMngrPtr mngr,
                                                                         const char* uri);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppDefaultKeysMngrSave (xmlSecKeysMngrPtr mngr,
                                                                         const char *filename,
                                                                         xmlSecKeyDataType type);
#ifndef XMLSEC_NO_X509
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeysMngrCertLoad    (xmlSecKeysMngrPtr mngr,
                                                                         const char *filename,
                                                                         xmlSecKeyDataFormat format,
                                                                         xmlSecKeyDataType type);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeysMngrCertLoadMemory (xmlSecKeysMngrPtr mngr,
                                                                         const xmlSecByte *data,
                                                                         xmlSecSize dataSize,
                                                                         xmlSecKeyDataFormat format,
                                                                         xmlSecKeyDataType type);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeysMngrCertLoadSECItem (xmlSecKeysMngrPtr mngr,
                                                                         SECItem* secItem,
                                                                         xmlSecKeyDataFormat format,
                                                                         xmlSecKeyDataType type);

XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeysMngrCrlLoad     (xmlSecKeysMngrPtr mngr,
                                                                         const char *filename,
                                                                         xmlSecKeyDataFormat format);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeysMngrCrlLoadMemory (xmlSecKeysMngrPtr mngr,
                                                                         const xmlSecByte *data,
                                                                         xmlSecSize dataSize,
                                                                         xmlSecKeyDataFormat format);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeysMngrCrlLoadAndVerify (xmlSecKeysMngrPtr mngr,
                                                                         const char *filename,
                                                                         xmlSecKeyDataFormat format,
                                                                         xmlSecKeyInfoCtxPtr keyInfoCtx);
#endif /* XMLSEC_NO_X509 */

/******************************************************************************
 *
 * Keys
 *
 * The following key loading functions accept a password (pwd) and a
 * password callback (pwdCallback). The password callback is used only
 * when pwd is NULL; an explicit password (even an empty one) wins. The
 * callback is expected to have the signature
 * int (*callback)(char* buf, int bufSize, int verify, void* userdata)
 * (the same as OpenSSL's pem_password_cb); it is called with verify set
 * to 0, must write the password to buf (up to bufSize - 1 characters),
 * and must return the number of characters written.
 *
  *****************************************************************************/
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppKeyLoadEx           (const char *filename,
                                                                         xmlSecKeyDataType type,
                                                                         xmlSecKeyDataFormat format,
                                                                         const char *pwd,
                                                                         void* pwdCallback,
                                                                         void* pwdCallbackCtx);
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppKeyLoadMemory       (const xmlSecByte *data,
                                                                         xmlSecSize dataSize,
                                                                         xmlSecKeyDataFormat format,
                                                                         const char *pwd,
                                                                         void* pwdCallback,
                                                                         void* pwdCallbackCtx);
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppKeyLoadSECItem      (SECItem* secItem,
                                                                         xmlSecKeyDataFormat format,
                                                                         const char *pwd,
                                                                         void* pwdCallback,
                                                                         void* pwdCallbackCtx);
#ifndef XMLSEC_NO_X509
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppPkcs12Load          (const char *filename,
                                                                         const char *pwd,
                                                                         void* pwdCallback,
                                                                         void* pwdCallbackCtx);
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppPkcs12LoadMemory    (const xmlSecByte *data,
                                                                         xmlSecSize dataSize,
                                                                         const char *pwd,
                                                                         void* pwdCallback,
                                                                         void* pwdCallbackCtx);
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppPkcs12LoadSECItem   (SECItem* secItem,
                                                                         const char *pwd,
                                                                         void* pwdCallback,
                                                                         void* pwdCallbackCtx);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeyCertLoad         (xmlSecKeyPtr key,
                                                                         const char *filename,
                                                                         xmlSecKeyDataFormat format);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeyCertLoadMemory   (xmlSecKeyPtr key,
                                                                         const xmlSecByte *data,
                                                                         xmlSecSize dataSize,
                                                                         xmlSecKeyDataFormat format);
XMLSEC_CRYPTO_EXPORT int                xmlSecNssAppKeyCertLoadSECItem  (xmlSecKeyPtr key,
                                                                         SECItem* secItem,
                                                                         xmlSecKeyDataFormat format);
XMLSEC_CRYPTO_EXPORT xmlSecKeyPtr       xmlSecNssAppKeyFromCertLoadSECItem (SECItem* secItem,
                                                                         xmlSecKeyDataFormat format);
#endif /* XMLSEC_NO_X509 */
XMLSEC_CRYPTO_EXPORT void*              xmlSecNssAppGetDefaultPwdCallback (void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */ /* xmlsec_nss_app */

#endif /* XMLSEC_NSS_APP_H */
