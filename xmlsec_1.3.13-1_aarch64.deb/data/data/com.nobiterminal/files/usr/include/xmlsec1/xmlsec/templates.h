/**
 * XML Security Library (http://www.aleksey.com/xmlsec).
 *
 * This is free software; see the Copyright file in the source distribution for precise wording.
 *
 * Copyright (C) 2002-2026 Aleksey Sanin <aleksey@aleksey.com>. All Rights Reserved.
 */
#ifndef XMLSEC_TEMPLATES_H
#define XMLSEC_TEMPLATES_H

/**
 * @defgroup xmlsec_core_templates XML Templates
 * @ingroup xmlsec_core
 * @brief Functions for creating XMLDSig and XMLEnc XML template elements/nodes.
 * @{
 */

#include <libxml/tree.h>

#include <xmlsec/exports.h>
#include <xmlsec/xmlsec.h>
#include <xmlsec/transforms.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/******************************************************************************
 *
 * &lt;dsig:Signature/&gt; node
 *
  *****************************************************************************/
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureCreate              (xmlDocPtr doc,
                                                                 xmlSecTransformId c14nMethodId,
                                                                 xmlSecTransformId signMethodId,
                                                                 const xmlChar *id);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureCreateNsPref        (xmlDocPtr doc,
                                                                 xmlSecTransformId c14nMethodId,
                                                                 xmlSecTransformId signMethodId,
                                                                 const xmlChar *id,
                                                                 const xmlChar *nsPrefix);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureEnsureKeyInfo       (xmlNodePtr signNode,
                                                                 const xmlChar *id);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureAddReference        (xmlNodePtr signNode,
                                                                 xmlSecTransformId digestMethodId,
                                                                 const xmlChar *id,
                                                                 const xmlChar *uri,
                                                                 const xmlChar *type);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureAddObject           (xmlNodePtr signNode,
                                                                 const xmlChar *id,
                                                                 const xmlChar *mimeType,
                                                                 const xmlChar *encoding);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureGetSignMethodNode   (xmlNodePtr signNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplSignatureGetC14NMethodNode   (xmlNodePtr signNode);

XMLSEC_EXPORT xmlNodePtr xmlSecTmplReferenceAddTransform        (xmlNodePtr referenceNode,
                                                                 xmlSecTransformId transformId);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplObjectAddSignProperties      (xmlNodePtr objectNode,
                                                                 const xmlChar *id,
                                                                 const xmlChar *target);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplObjectAddManifest            (xmlNodePtr objectNode,
                                                                 const xmlChar *id);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplManifestAddReference         (xmlNodePtr manifestNode,
                                                                 xmlSecTransformId digestMethodId,
                                                                 const xmlChar *id,
                                                                 const xmlChar *uri,
                                                                 const xmlChar *type);

/******************************************************************************
 *
 * &lt;enc:EncryptedData/&gt; node
 *
  *****************************************************************************/
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataCreate                (xmlDocPtr doc,
                                                                 xmlSecTransformId encMethodId,
                                                                 const xmlChar *id,
                                                                 const xmlChar *type,
                                                                 const xmlChar *mimeType,
                                                                 const xmlChar *encoding);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataEnsureKeyInfo         (xmlNodePtr encNode,
                                                                 const xmlChar *id);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataEnsureEncProperties   (xmlNodePtr encNode,
                                                                 const xmlChar *id);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataAddEncProperty        (xmlNodePtr encNode,
                                                                 const xmlChar *id,
                                                                 const xmlChar *target);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataEnsureCipherValue     (xmlNodePtr encNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataEnsureCipherReference (xmlNodePtr encNode,
                                                                 const xmlChar *uri);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplEncDataGetEncMethodNode      (xmlNodePtr encNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplCipherReferenceAddTransform  (xmlNodePtr cipherReferenceNode,
                                                                 xmlSecTransformId transformId);

/******************************************************************************
 *
 * &lt;enc:EncryptedKey/&gt; node
 *
  *****************************************************************************/
XMLSEC_EXPORT xmlNodePtr xmlSecTmplReferenceListAddDataReference(xmlNodePtr encNode,
                                                                 const xmlChar *uri);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplReferenceListAddKeyReference (xmlNodePtr encNode,
                                                                 const xmlChar *uri);

/******************************************************************************
 *
 * &lt;dsig:KeyInfo/&gt; node
 *
  *****************************************************************************/
XMLSEC_EXPORT xmlNodePtr xmlSecTmplKeyInfoAddKeyName            (xmlNodePtr keyInfoNode,
                                                                 const xmlChar *name);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplKeyInfoAddKeyValue           (xmlNodePtr keyInfoNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplKeyInfoAddX509Data           (xmlNodePtr keyInfoNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplKeyInfoAddRetrievalMethod    (xmlNodePtr keyInfoNode,
                                                                 const xmlChar *uri,
                                                                 const xmlChar *type);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplRetrievalMethodAddTransform  (xmlNodePtr retrMethodNode,
                                                                 xmlSecTransformId transformId);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplKeyInfoAddEncryptedKey       (xmlNodePtr keyInfoNode,
                                                                 xmlSecTransformId encMethodId,
                                                                 const xmlChar *id,
                                                                 const xmlChar *type,
                                                                 const xmlChar *recipient);

/******************************************************************************
 *
 * &lt;dsig:X509Data/&gt; node
 *
  *****************************************************************************/
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509DataAddIssuerSerial      (xmlNodePtr x509DataNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509IssuerSerialAddIssuerName(xmlNodePtr x509IssuerSerialNode, const xmlChar *issuerName);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509IssuerSerialAddSerialNumber (xmlNodePtr x509IssuerSerialNode, const xmlChar *serial);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509DataAddSubjectName       (xmlNodePtr x509DataNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509DataAddSKI               (xmlNodePtr x509DataNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509DataAddDigest            (xmlNodePtr x509DataNode, const xmlChar *digestAlgorithm);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509DataAddCertificate       (xmlNodePtr x509DataNode);
XMLSEC_EXPORT xmlNodePtr xmlSecTmplX509DataAddCRL               (xmlNodePtr x509DataNode);

/******************************************************************************
 *
 * &lt;dsig:Transform/&gt; node
 *
  *****************************************************************************/
XMLSEC_EXPORT int       xmlSecTmplTransformAddHmacOutputLength  (xmlNodePtr transformNode,
                                                                 xmlSecSize bitsLen);
XMLSEC_EXPORT int       xmlSecTmplTransformAddRsaOaepParam      (xmlNodePtr transformNode,
                                                                 const xmlSecByte *buf,
                                                                 xmlSecSize size);
XMLSEC_EXPORT int       xmlSecTmplTransformAddRsaMgf            (xmlNodePtr transformNode,
                                                                 const xmlChar *algorithm);
XMLSEC_EXPORT int       xmlSecTmplTransformAddRsaDigest         (xmlNodePtr transformNode,
                                                                 const xmlChar *algorithm);
XMLSEC_EXPORT int       xmlSecTmplTransformAddXsltStylesheet    (xmlNodePtr transformNode,
                                                                 const xmlChar *xslt);
XMLSEC_EXPORT int       xmlSecTmplTransformAddC14NInclNamespaces(xmlNodePtr transformNode,
                                                                 const xmlChar *prefixList);
XMLSEC_EXPORT int       xmlSecTmplTransformAddXPath             (xmlNodePtr transformNode,
                                                                 const xmlChar *expression,
                                                                 const xmlChar **nsList);
XMLSEC_EXPORT int       xmlSecTmplTransformAddXPath2            (xmlNodePtr transformNode,
                                                                 const xmlChar *type,
                                                                 const xmlChar *expression,
                                                                 const xmlChar **nsList);
XMLSEC_EXPORT int       xmlSecTmplTransformAddXPointer          (xmlNodePtr transformNode,
                                                                 const xmlChar *expression,
                                                                 const xmlChar **nsList);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */ /* xmlsec_core_templates */

#endif /* XMLSEC_TEMPLATES_H */
