/**
 * XML Security Library (http://www.aleksey.com/xmlsec).
 *
 * This is free software; see the Copyright file in the source distribution for precise wording.
 *
 * Copyright (C) 2003-2026 Aleksey Sanin <aleksey@aleksey.com>. All Rights Reserved.
 * Copyright (c) 2003 America Online, Inc.  All rights reserved.
 */
#ifndef XMLSEC_NSS_PKIKEYS_H
#define XMLSEC_NSS_PKIKEYS_H

/**
 * @defgroup xmlsec_nss_pkikeys NSS PKI Keys
 * @ingroup xmlsec_nss
 * @brief PKI key-data handling for the NSS back-end.
 * @{
 */

#include <nspr.h>
#include <nss.h>
#include <keyhi.h>

#include <xmlsec/exports.h>
#include <xmlsec/keys.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

XMLSEC_CRYPTO_EXPORT xmlSecKeyDataPtr   xmlSecNssPKIAdoptKey            (SECKEYPrivateKey *privkey,
                                                                         SECKEYPublicKey  *pubkey);

XMLSEC_CRYPTO_EXPORT SECKEYPublicKey *  xmlSecNssPKIKeyDataGetPubKey    (xmlSecKeyDataPtr data);

XMLSEC_CRYPTO_EXPORT SECKEYPrivateKey * xmlSecNssPKIKeyDataGetPrivKey   (xmlSecKeyDataPtr data);

XMLSEC_CRYPTO_EXPORT KeyType            xmlSecNssPKIKeyDataGetKeyType   (xmlSecKeyDataPtr data);

XMLSEC_CRYPTO_EXPORT int                xmlSecNssPKIKeyDataDuplicate    (xmlSecKeyDataPtr dst,
                                                                         xmlSecKeyDataPtr src);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */ /* xmlsec_nss_pkikeys */

#endif /* XMLSEC_NSS_PKIKEYS_H */
