/**
 * XML Security Library (http://www.aleksey.com/xmlsec).
 *
 * This is free software; see the Copyright file in the source distribution for precise wording.
 *
 * Copyright (C) 2003-2026 Aleksey Sanin <aleksey@aleksey.com>. All Rights Reserved.
 */
#ifndef XMLSEC_OPENSSL_KEYSSTORE_H
#define XMLSEC_OPENSSL_KEYSSTORE_H

/**
 * @defgroup xmlsec_openssl_keysstore OpenSSL Keys Store
 * @ingroup xmlsec_openssl
 * @brief OpenSSL-specific key store implementation.
 * @{
 */

#include <xmlsec/exports.h>
#include <xmlsec/xmlsec.h>
#include <xmlsec/keysmngr.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/******************************************************************************
 *
 * OpenSSL Keys Store
 *
  *****************************************************************************/
/**
 * @brief An OpenSSL keys store klass id.
 */
#define xmlSecOpenSSLKeysStoreId        xmlSecOpenSSLKeysStoreGetKlass()
XMLSEC_CRYPTO_EXPORT xmlSecKeyStoreId   xmlSecOpenSSLKeysStoreGetKlass(void);

XMLSEC_CRYPTO_EXPORT int                xmlSecOpenSSLKeysStoreAdoptKey(xmlSecKeyStorePtr store,
                                                                       xmlSecKeyPtr key);
XMLSEC_CRYPTO_EXPORT int                xmlSecOpenSSLKeysStoreLoad    (xmlSecKeyStorePtr store,
                                                                       const char *uri,
                                                                       xmlSecKeysMngrPtr keysMngr);
XMLSEC_CRYPTO_EXPORT int                xmlSecOpenSSLKeysStoreSave    (xmlSecKeyStorePtr store,
                                                                       const char *filename,
                                                                       xmlSecKeyDataType type);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */ /* xmlsec_openssl_keysstore */

#endif /* XMLSEC_OPENSSL_KEYSSTORE_H */
