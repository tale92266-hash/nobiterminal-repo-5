#!/data/data/com.nobiterminal/files/usr/bin/sh
#
# Configuration file for the XML Security Library (xmlsec)
#
prefix="/data/data/com.nobiterminal/files/usr"
exec_prefix="${prefix}"
libdir="/data/data/com.nobiterminal/files/usr/lib"
includedir="/data/data/com.nobiterminal/files/usr/include"

XMLSEC_LIBDIR="/data/data/com.nobiterminal/files/usr/lib"
XMLSEC_CFLAGS=" -DXMLSEC_FUNCTION=__func__ -DXMLSEC_NO_FTP=1 -DXMLSEC_NO_HTTP=1 -DXMLSEC_NO_MD5=1 -DXMLSEC_NO_RIPEMD160=1 -DXMLSEC_NO_MLDSA=1 -DXMLSEC_NO_MLKEM=1 -DXMLSEC_NO_SLHDSA=1 -DXMLSEC_NO_GOST=1 -DXMLSEC_NO_GOST2012=1 -DXMLSEC_NO_CRYPTO_DYNAMIC_LOADING=1 -I/data/data/com.nobiterminal/files/usr/include/xmlsec1  -I/data/data/com.nobiterminal/files/usr/include/libxml2 -I/data/data/com.nobiterminal/files/usr/include -I/data/data/com.nobiterminal/files/usr/include -I/data/data/com.nobiterminal/files/usr/include/libxml2 -I/data/data/com.nobiterminal/files/usr/include -DXMLSEC_CRYPTO_OPENSSL=1"
XMLSEC_LIBS="-L/data/data/com.nobiterminal/files/usr/lib -lxmlsec1-openssl -lxmlsec1   -L/data/data/com.nobiterminal/files/usr/lib -lxml2 -L/data/data/com.nobiterminal/files/usr/lib -lxslt -lxml2 -L/data/data/com.nobiterminal/files/usr/lib -lssl -lcrypto"
MODULE_VERSION="xmlsec-1.3.13-openssl"

