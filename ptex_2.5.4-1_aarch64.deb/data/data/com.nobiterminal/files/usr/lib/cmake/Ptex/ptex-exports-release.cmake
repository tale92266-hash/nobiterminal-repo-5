#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ptex::Ptex_static" for configuration "Release"
set_property(TARGET Ptex::Ptex_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ptex::Ptex_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libPtex.a"
  )

list(APPEND _cmake_import_check_targets Ptex::Ptex_static )
list(APPEND _cmake_import_check_files_for_Ptex::Ptex_static "/data/data/com.nobiterminal/files/usr/lib/libPtex.a" )

# Import target "Ptex::Ptex_dynamic" for configuration "Release"
set_property(TARGET Ptex::Ptex_dynamic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Ptex::Ptex_dynamic PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "libdeflate::libdeflate_shared"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libPtex.so"
  IMPORTED_SONAME_RELEASE "libPtex.so"
  )

list(APPEND _cmake_import_check_targets Ptex::Ptex_dynamic )
list(APPEND _cmake_import_check_files_for_Ptex::Ptex_dynamic "/data/data/com.nobiterminal/files/usr/lib/libPtex.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
