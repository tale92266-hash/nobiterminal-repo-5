#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qrupdate::qrupdate" for configuration "Release"
set_property(TARGET qrupdate::qrupdate APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(qrupdate::qrupdate PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libqrupdate.so.1.3.1"
  IMPORTED_SONAME_RELEASE "libqrupdate.so.1"
  )

list(APPEND _cmake_import_check_targets qrupdate::qrupdate )
list(APPEND _cmake_import_check_files_for_qrupdate::qrupdate "/data/data/com.nobiterminal/files/usr/lib/libqrupdate.so.1.3.1" )

# Import target "qrupdate::qrupdate_static" for configuration "Release"
set_property(TARGET qrupdate::qrupdate_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(qrupdate::qrupdate_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;Fortran"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libqrupdate.a"
  )

list(APPEND _cmake_import_check_targets qrupdate::qrupdate_static )
list(APPEND _cmake_import_check_files_for_qrupdate::qrupdate_static "/data/data/com.nobiterminal/files/usr/lib/libqrupdate.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
