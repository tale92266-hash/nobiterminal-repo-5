﻿!mod$ v1 sum:2e91ea7976e25ac0
!need$ f0ab81c8387ca406 i iso_fortran_env
module qrupdate
use,intrinsic::iso_fortran_env,only:event_type
use,intrinsic::iso_fortran_env,only:notify_type
use,intrinsic::iso_fortran_env,only:lock_type
use,intrinsic::iso_fortran_env,only:team_type
use,intrinsic::iso_fortran_env,only:atomic_int_kind
use,intrinsic::iso_fortran_env,only:atomic_logical_kind
use,intrinsic::iso_fortran_env,only:compiler_options
use,intrinsic::iso_fortran_env,only:compiler_version
use,intrinsic::iso_fortran_env,only:selectedint8
use,intrinsic::iso_fortran_env,only:selectedint16
use,intrinsic::iso_fortran_env,only:selectedint32
use,intrinsic::iso_fortran_env,only:selectedint64
use,intrinsic::iso_fortran_env,only:selectedint128
use,intrinsic::iso_fortran_env,only:safeint8
use,intrinsic::iso_fortran_env,only:safeint16
use,intrinsic::iso_fortran_env,only:safeint32
use,intrinsic::iso_fortran_env,only:safeint64
use,intrinsic::iso_fortran_env,only:safeint128
use,intrinsic::iso_fortran_env,only:int8
use,intrinsic::iso_fortran_env,only:int16
use,intrinsic::iso_fortran_env,only:int32
use,intrinsic::iso_fortran_env,only:int64
use,intrinsic::iso_fortran_env,only:int128
use,intrinsic::iso_fortran_env,only:selecteduint8
use,intrinsic::iso_fortran_env,only:selecteduint16
use,intrinsic::iso_fortran_env,only:selecteduint32
use,intrinsic::iso_fortran_env,only:selecteduint64
use,intrinsic::iso_fortran_env,only:selecteduint128
use,intrinsic::iso_fortran_env,only:safeuint8
use,intrinsic::iso_fortran_env,only:safeuint16
use,intrinsic::iso_fortran_env,only:safeuint32
use,intrinsic::iso_fortran_env,only:safeuint64
use,intrinsic::iso_fortran_env,only:safeuint128
use,intrinsic::iso_fortran_env,only:uint8
use,intrinsic::iso_fortran_env,only:uint16
use,intrinsic::iso_fortran_env,only:uint32
use,intrinsic::iso_fortran_env,only:uint64
use,intrinsic::iso_fortran_env,only:uint128
use,intrinsic::iso_fortran_env,only:logical8
use,intrinsic::iso_fortran_env,only:logical16
use,intrinsic::iso_fortran_env,only:logical32
use,intrinsic::iso_fortran_env,only:logical64
use,intrinsic::iso_fortran_env,only:selectedreal16
use,intrinsic::iso_fortran_env,only:selectedbfloat16
use,intrinsic::iso_fortran_env,only:selectedreal32
use,intrinsic::iso_fortran_env,only:selectedreal64
use,intrinsic::iso_fortran_env,only:selectedreal80
use,intrinsic::iso_fortran_env,only:selectedreal64x2
use,intrinsic::iso_fortran_env,only:selectedreal128
use,intrinsic::iso_fortran_env,only:safereal16
use,intrinsic::iso_fortran_env,only:safebfloat16
use,intrinsic::iso_fortran_env,only:safereal32
use,intrinsic::iso_fortran_env,only:safereal64
use,intrinsic::iso_fortran_env,only:safereal80
use,intrinsic::iso_fortran_env,only:safereal64x2
use,intrinsic::iso_fortran_env,only:safereal128
use,intrinsic::iso_fortran_env,only:real16
use,intrinsic::iso_fortran_env,only:bfloat16
use,intrinsic::iso_fortran_env,only:real32
use,intrinsic::iso_fortran_env,only:real64
use,intrinsic::iso_fortran_env,only:real80
use,intrinsic::iso_fortran_env,only:real64x2
use,intrinsic::iso_fortran_env,only:real128
use,intrinsic::iso_fortran_env,only:integer_kinds
use,intrinsic::iso_fortran_env,only:real_kinds
use,intrinsic::iso_fortran_env,only:logical_kinds
use,intrinsic::iso_fortran_env,only:character_kinds
use,intrinsic::iso_fortran_env,only:current_team
use,intrinsic::iso_fortran_env,only:initial_team
use,intrinsic::iso_fortran_env,only:parent_team
use,intrinsic::iso_fortran_env,only:character_storage_size
use,intrinsic::iso_fortran_env,only:file_storage_size
use,intrinsic::iso_fortran_env,only:numeric_storage_size
use,intrinsic::iso_fortran_env,only:output_unit
use,intrinsic::iso_fortran_env,only:input_unit
use,intrinsic::iso_fortran_env,only:error_unit
use,intrinsic::iso_fortran_env,only:iostat_end
use,intrinsic::iso_fortran_env,only:iostat_eor
use,intrinsic::iso_fortran_env,only:iostat_inquire_internal_unit
use,intrinsic::iso_fortran_env,only:stat_failed_image
use,intrinsic::iso_fortran_env,only:stat_locked
use,intrinsic::iso_fortran_env,only:stat_locked_other_image
use,intrinsic::iso_fortran_env,only:stat_stopped_image
use,intrinsic::iso_fortran_env,only:stat_unlocked
use,intrinsic::iso_fortran_env,only:stat_unlocked_failed_image
interface
subroutine caxcpy(n,a,x,incx,y,incy)
integer(4),intent(in)::n
complex(4),intent(in)::a
complex(4),intent(in)::x(1_8:*)
integer(4),intent(in)::incx
complex(4),intent(inout)::y(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine cch1dn(n,r,ldr,u,rw,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(4),intent(inout)::u(1_8:*)
real(4),intent(out)::rw(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine cch1up(n,r,ldr,u,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(4),intent(inout)::u(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine cchdex(n,r,ldr,j,rw)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cchinx(n,r,ldr,j,u,rw,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(4),intent(inout)::u(1_8:*)
real(4),intent(out)::rw(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine cchshx(n,r,ldr,i,j,w,rw)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
complex(4),intent(out)::w(1_8:*)
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cgqvec(m,n,q,ldq,u)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(4),intent(in)::q(1_8:int(ldq,kind=8),1_8:*)
complex(4),intent(out)::u(1_8:*)
end
end interface
interface
subroutine clu1up(m,n,l,ldl,r,ldr,u,v)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
complex(4),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(4),intent(inout)::u(1_8:*)
complex(4),intent(inout)::v(1_8:*)
end
end interface
interface
subroutine clup1up(m,n,l,ldl,r,ldr,p,u,v,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
complex(4),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(inout)::p(1_8:*)
complex(4),intent(in)::u(1_8:*)
complex(4),intent(in)::v(1_8:*)
complex(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine cqhqr(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(out)::c(1_8:*)
complex(4),intent(out)::s(1_8:*)
end
end interface
interface
subroutine cqr1up(m,n,k,q,ldq,r,ldr,u,v,w,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(4),intent(inout)::u(1_8:*)
complex(4),intent(inout)::v(1_8:*)
complex(4),intent(out)::w(1_8:*)
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cqrdec(m,n,k,q,ldq,r,ldr,j,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cqrder(m,n,q,ldq,r,ldr,j,w,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(4),intent(out)::w(1_8:*)
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cqrinc(m,n,k,q,ldq,r,ldr,j,x,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(4),intent(in)::x(1_8:*)
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cqrinr(m,n,q,ldq,r,ldr,j,x,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(4),intent(inout)::x(1_8:*)
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cqrot(dir,m,n,q,ldq,c,s)
character(*,1),intent(in)::dir
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
real(4),intent(in)::c(1_8:*)
complex(4),intent(in)::s(1_8:*)
end
end interface
interface
subroutine cqrqh(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(in)::c(1_8:*)
complex(4),intent(in)::s(1_8:*)
end
end interface
interface
subroutine cqrshc(m,n,k,q,ldq,r,ldr,i,j,w,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
complex(4),intent(out)::w(1_8:*)
real(4),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine cqrtv1(n,u,w)
integer(4),intent(in)::n
complex(4),intent(inout)::u(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dch1dn(n,r,ldr,u,w,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(inout)::u(1_8:*)
real(8),intent(out)::w(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine dch1up(n,r,ldr,u,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(inout)::u(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dchdex(n,r,ldr,j,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dchinx(n,r,ldr,j,u,w,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(inout)::u(1_8:*)
real(8),intent(out)::w(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine dchshx(n,r,ldr,i,j,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dgqvec(m,n,q,ldq,u)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(8),intent(in)::q(1_8:int(ldq,kind=8),1_8:*)
real(8),intent(out)::u(1_8:*)
end
end interface
interface
subroutine dlu1up(m,n,l,ldl,r,ldr,u,v)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
real(8),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(inout)::u(1_8:*)
real(8),intent(inout)::v(1_8:*)
end
end interface
interface
subroutine dlup1up(m,n,l,ldl,r,ldr,p,u,v,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
real(8),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(inout)::p(1_8:*)
real(8),intent(in)::u(1_8:*)
real(8),intent(in)::v(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqhqr(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(out)::c(1_8:*)
real(8),intent(out)::s(1_8:*)
end
end interface
interface
subroutine dqr1up(m,n,k,q,ldq,r,ldr,u,v,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(inout)::u(1_8:*)
real(8),intent(inout)::v(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqrdec(m,n,k,q,ldq,r,ldr,j,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqrder(m,n,q,ldq,r,ldr,j,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqrinc(m,n,k,q,ldq,r,ldr,j,x,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(in)::x(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqrinr(m,n,q,ldq,r,ldr,j,x,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(inout)::x(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqrot(dir,m,n,q,ldq,c,s)
character(*,1),intent(in)::dir
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
real(8),intent(in)::c(1_8:*)
real(8),intent(in)::s(1_8:*)
end
end interface
interface
subroutine dqrqh(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(in)::c(1_8:*)
real(8),intent(in)::s(1_8:*)
end
end interface
interface
subroutine dqrshc(m,n,k,q,ldq,r,ldr,i,j,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine dqrtv1(n,u,w)
integer(4),intent(in)::n
real(8),intent(inout)::u(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine qrupdate_cdotc(ret,n,cx,incx,cy,incy)
complex(4),intent(out)::ret
integer(4),intent(in)::n
complex(4),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(4),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine qrupdate_cdotu(ret,n,cx,incx,cy,incy)
complex(4),intent(out)::ret
integer(4),intent(in)::n
complex(4),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(4),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine qrupdate_zdotc(ret,n,cx,incx,cy,incy)
complex(8),intent(out)::ret
integer(4),intent(in)::n
complex(8),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(8),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine qrupdate_zdotu(ret,n,cx,incx,cy,incy)
complex(4),intent(out)::ret
integer(4),intent(in)::n
complex(4),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(4),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine sch1dn(n,r,ldr,u,w,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(inout)::u(1_8:*)
real(4),intent(out)::w(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine sch1up(n,r,ldr,u,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(inout)::u(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine schdex(n,r,ldr,j,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine schinx(n,r,ldr,j,u,w,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(inout)::u(1_8:*)
real(4),intent(out)::w(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine schshx(n,r,ldr,i,j,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sgqvec(m,n,q,ldq,u)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(4),intent(in)::q(1_8:int(ldq,kind=8),1_8:*)
real(4),intent(out)::u(1_8:*)
end
end interface
interface
subroutine slu1up(m,n,l,ldl,r,ldr,u,v)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
real(4),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(inout)::u(1_8:*)
real(4),intent(inout)::v(1_8:*)
end
end interface
interface
subroutine slup1up(m,n,l,ldl,r,ldr,p,u,v,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
real(4),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(inout)::p(1_8:*)
real(4),intent(in)::u(1_8:*)
real(4),intent(in)::v(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqhqr(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(in)::c(1_8:*)
real(4),intent(in)::s(1_8:*)
end
end interface
interface
subroutine sqr1up(m,n,k,q,ldq,r,ldr,u,v,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(inout)::u(1_8:*)
real(4),intent(inout)::v(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqrdec(m,n,k,q,ldq,r,ldr,j,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqrder(m,n,q,ldq,r,ldr,j,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqrinc(m,n,k,q,ldq,r,ldr,j,x,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(in)::x(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqrinr(m,n,q,ldq,r,ldr,j,x,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(4),intent(inout)::x(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqrot(dir,m,n,q,ldq,c,s)
character(*,1),intent(in)::dir
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
real(4),intent(in)::c(1_8:*)
real(4),intent(in)::s(1_8:*)
end
end interface
interface
subroutine sqrqh(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(4),intent(in)::c(1_8:*)
real(4),intent(in)::s(1_8:*)
end
end interface
interface
subroutine sqrshc(m,n,k,q,ldq,r,ldr,i,j,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
real(4),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
real(4),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine sqrtv1(n,u,w)
integer(4),intent(in)::n
real(4),intent(inout)::u(1_8:*)
real(4),intent(out)::w(1_8:*)
end
end interface
interface
subroutine zaxcpy(n,a,x,incx,y,incy)
integer(4),intent(in)::n
complex(8),intent(in)::a
complex(8),intent(in)::x(1_8:*)
integer(4),intent(in)::incx
complex(8),intent(inout)::y(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine zch1dn(n,r,ldr,u,rw,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(8),intent(inout)::u(1_8:*)
real(8),intent(out)::rw(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine zch1up(n,r,ldr,u,w)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(8),intent(inout)::u(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine zchdex(n,r,ldr,j,rw)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zchinx(n,r,ldr,j,u,rw,info)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(8),intent(inout)::u(1_8:*)
real(8),intent(out)::rw(1_8:*)
integer(4),intent(out)::info
end
end interface
interface
subroutine zchshx(n,r,ldr,i,j,w,rw)
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
complex(8),intent(out)::w(1_8:*)
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zgqvec(m,n,q,ldq,u)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(8),intent(in)::q(1_8:int(ldq,kind=8),1_8:*)
complex(8),intent(out)::u(1_8:*)
end
end interface
interface
subroutine zlu1up(m,n,l,ldl,r,ldr,u,v)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
complex(8),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(8),intent(inout)::u(1_8:*)
complex(8),intent(inout)::v(1_8:*)
end
end interface
interface
subroutine zlup1up(m,n,l,ldl,r,ldr,p,u,v,w)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldl
complex(8),intent(inout)::l(1_8:int(ldl,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(inout)::p(1_8:*)
complex(8),intent(in)::u(1_8:*)
complex(8),intent(in)::v(1_8:*)
complex(8),intent(out)::w(1_8:*)
end
end interface
interface
subroutine zqhqr(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(out)::c(1_8:*)
complex(8),intent(out)::s(1_8:*)
end
end interface
interface
subroutine zqr1up(m,n,k,q,ldq,r,ldr,u,v,w,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
complex(8),intent(inout)::u(1_8:*)
complex(8),intent(inout)::v(1_8:*)
complex(8),intent(out)::w(1_8:*)
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zqrdec(m,n,k,q,ldq,r,ldr,j,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zqrder(m,n,q,ldq,r,ldr,j,w,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(8),intent(out)::w(1_8:*)
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zqrinc(m,n,k,q,ldq,r,ldr,j,x,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(8),intent(in)::x(1_8:*)
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zqrinr(m,n,q,ldq,r,ldr,j,x,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::j
complex(8),intent(inout)::x(1_8:*)
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zqrot(dir,m,n,q,ldq,c,s)
character(*,1),intent(in)::dir
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
real(8),intent(in)::c(1_8:*)
complex(8),intent(in)::s(1_8:*)
end
end interface
interface
subroutine zqrqh(m,n,r,ldr,c,s)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
real(8),intent(in)::c(1_8:*)
complex(8),intent(in)::s(1_8:*)
end
end interface
interface
subroutine zqrshc(m,n,k,q,ldq,r,ldr,i,j,w,rw)
integer(4),intent(in)::m
integer(4),intent(in)::n
integer(4),intent(in)::k
integer(4),intent(in)::ldq
complex(8),intent(inout)::q(1_8:int(ldq,kind=8),1_8:*)
integer(4),intent(in)::ldr
complex(8),intent(inout)::r(1_8:int(ldr,kind=8),1_8:*)
integer(4),intent(in)::i
integer(4),intent(in)::j
complex(8),intent(out)::w(1_8:*)
real(8),intent(out)::rw(1_8:*)
end
end interface
interface
subroutine zqrtv1(n,u,w)
integer(4),intent(in)::n
complex(8),intent(inout)::u(1_8:*)
real(8),intent(out)::w(1_8:*)
end
end interface
end
