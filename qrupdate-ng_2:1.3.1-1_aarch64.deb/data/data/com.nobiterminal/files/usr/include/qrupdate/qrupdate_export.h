
#ifndef QRUPDATE_EXPORT_H
#define QRUPDATE_EXPORT_H

#ifdef QRUPDATE_STATIC
#  define QRUPDATE_EXPORT
#  define QRUPDATE_NO_EXPORT
#else
#  ifndef QRUPDATE_EXPORT
#    ifdef qrupdate_EXPORTS
        /* We are building this library */
#      define QRUPDATE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define QRUPDATE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef QRUPDATE_NO_EXPORT
#    define QRUPDATE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef QRUPDATE_DEPRECATED
#  define QRUPDATE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef QRUPDATE_DEPRECATED_EXPORT
#  define QRUPDATE_DEPRECATED_EXPORT QRUPDATE_EXPORT QRUPDATE_DEPRECATED
#endif

#ifndef QRUPDATE_DEPRECATED_NO_EXPORT
#  define QRUPDATE_DEPRECATED_NO_EXPORT QRUPDATE_NO_EXPORT QRUPDATE_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef QRUPDATE_NO_DEPRECATED
#    define QRUPDATE_NO_DEPRECATED
#  endif
#endif

#endif /* QRUPDATE_EXPORT_H */
