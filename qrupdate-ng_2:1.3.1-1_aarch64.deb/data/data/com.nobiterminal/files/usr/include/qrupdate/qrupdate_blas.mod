﻿!mod$ v1 sum:82d0a84a790d391a
!need$ f0ab81c8387ca406 i iso_fortran_env
module qrupdate_blas
use,intrinsic::iso_fortran_env,only:event_type
use,intrinsic::iso_fortran_env,only:notify_type
use,intrinsic::iso_fortran_env,only:lock_type
use,intrinsic::iso_fortran_env,only:team_type
use,intrinsic::iso_fortran_env,only:atomic_int_kind
use,intrinsic::iso_fortran_env,only:atomic_logical_kind
use,intrinsic::iso_fortran_env,only:compiler_options
use,intrinsic::iso_fortran_env,only:compiler_version
use,intrinsic::iso_fortran_env,only:selectedint8
use,intrinsic::iso_fortran_env,only:selectedint16
use,intrinsic::iso_fortran_env,only:selectedint32
use,intrinsic::iso_fortran_env,only:selectedint64
use,intrinsic::iso_fortran_env,only:selectedint128
use,intrinsic::iso_fortran_env,only:safeint8
use,intrinsic::iso_fortran_env,only:safeint16
use,intrinsic::iso_fortran_env,only:safeint32
use,intrinsic::iso_fortran_env,only:safeint64
use,intrinsic::iso_fortran_env,only:safeint128
use,intrinsic::iso_fortran_env,only:int8
use,intrinsic::iso_fortran_env,only:int16
use,intrinsic::iso_fortran_env,only:int32
use,intrinsic::iso_fortran_env,only:int64
use,intrinsic::iso_fortran_env,only:int128
use,intrinsic::iso_fortran_env,only:selecteduint8
use,intrinsic::iso_fortran_env,only:selecteduint16
use,intrinsic::iso_fortran_env,only:selecteduint32
use,intrinsic::iso_fortran_env,only:selecteduint64
use,intrinsic::iso_fortran_env,only:selecteduint128
use,intrinsic::iso_fortran_env,only:safeuint8
use,intrinsic::iso_fortran_env,only:safeuint16
use,intrinsic::iso_fortran_env,only:safeuint32
use,intrinsic::iso_fortran_env,only:safeuint64
use,intrinsic::iso_fortran_env,only:safeuint128
use,intrinsic::iso_fortran_env,only:uint8
use,intrinsic::iso_fortran_env,only:uint16
use,intrinsic::iso_fortran_env,only:uint32
use,intrinsic::iso_fortran_env,only:uint64
use,intrinsic::iso_fortran_env,only:uint128
use,intrinsic::iso_fortran_env,only:logical8
use,intrinsic::iso_fortran_env,only:logical16
use,intrinsic::iso_fortran_env,only:logical32
use,intrinsic::iso_fortran_env,only:logical64
use,intrinsic::iso_fortran_env,only:selectedreal16
use,intrinsic::iso_fortran_env,only:selectedbfloat16
use,intrinsic::iso_fortran_env,only:selectedreal32
use,intrinsic::iso_fortran_env,only:selectedreal64
use,intrinsic::iso_fortran_env,only:selectedreal80
use,intrinsic::iso_fortran_env,only:selectedreal64x2
use,intrinsic::iso_fortran_env,only:selectedreal128
use,intrinsic::iso_fortran_env,only:safereal16
use,intrinsic::iso_fortran_env,only:safebfloat16
use,intrinsic::iso_fortran_env,only:safereal32
use,intrinsic::iso_fortran_env,only:safereal64
use,intrinsic::iso_fortran_env,only:safereal80
use,intrinsic::iso_fortran_env,only:safereal64x2
use,intrinsic::iso_fortran_env,only:safereal128
use,intrinsic::iso_fortran_env,only:real16
use,intrinsic::iso_fortran_env,only:bfloat16
use,intrinsic::iso_fortran_env,only:real32
use,intrinsic::iso_fortran_env,only:real64
use,intrinsic::iso_fortran_env,only:real80
use,intrinsic::iso_fortran_env,only:real64x2
use,intrinsic::iso_fortran_env,only:real128
use,intrinsic::iso_fortran_env,only:integer_kinds
use,intrinsic::iso_fortran_env,only:real_kinds
use,intrinsic::iso_fortran_env,only:logical_kinds
use,intrinsic::iso_fortran_env,only:character_kinds
use,intrinsic::iso_fortran_env,only:current_team
use,intrinsic::iso_fortran_env,only:initial_team
use,intrinsic::iso_fortran_env,only:parent_team
use,intrinsic::iso_fortran_env,only:character_storage_size
use,intrinsic::iso_fortran_env,only:file_storage_size
use,intrinsic::iso_fortran_env,only:numeric_storage_size
use,intrinsic::iso_fortran_env,only:output_unit
use,intrinsic::iso_fortran_env,only:input_unit
use,intrinsic::iso_fortran_env,only:error_unit
use,intrinsic::iso_fortran_env,only:iostat_end
use,intrinsic::iso_fortran_env,only:iostat_eor
use,intrinsic::iso_fortran_env,only:iostat_inquire_internal_unit
use,intrinsic::iso_fortran_env,only:stat_failed_image
use,intrinsic::iso_fortran_env,only:stat_locked
use,intrinsic::iso_fortran_env,only:stat_locked_other_image
use,intrinsic::iso_fortran_env,only:stat_stopped_image
use,intrinsic::iso_fortran_env,only:stat_unlocked
use,intrinsic::iso_fortran_env,only:stat_unlocked_failed_image
interface
subroutine qrupdate_cdotc(ret,n,cx,incx,cy,incy)
complex(4),intent(out)::ret
integer(4),intent(in)::n
complex(4),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(4),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine qrupdate_cdotu(ret,n,cx,incx,cy,incy)
complex(4),intent(out)::ret
integer(4),intent(in)::n
complex(4),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(4),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine qrupdate_zdotc(ret,n,cx,incx,cy,incy)
complex(8),intent(out)::ret
integer(4),intent(in)::n
complex(8),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(8),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine qrupdate_zdotu(ret,n,cx,incx,cy,incy)
complex(8),intent(out)::ret
integer(4),intent(in)::n
complex(8),intent(in)::cx(1_8:*)
integer(4),intent(in)::incx
complex(8),intent(in)::cy(1_8:*)
integer(4),intent(in)::incy
end
end interface
interface
subroutine xerbla(srname,info)
character(*,1),intent(in)::srname
integer(4),intent(in)::info
end
end interface
contains
function lsame(ca,cb)
character(1_8,1),intent(in)::ca
character(1_8,1),intent(in)::cb
logical(4)::lsame
end
end
