#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "pystring::pystring" for configuration "Release"
set_property(TARGET pystring::pystring APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(pystring::pystring PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libpystring.so"
  IMPORTED_SONAME_RELEASE "libpystring.so"
  )

list(APPEND _cmake_import_check_targets pystring::pystring )
list(APPEND _cmake_import_check_files_for_pystring::pystring "/data/data/com.nobiterminal/files/usr/lib/libpystring.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
