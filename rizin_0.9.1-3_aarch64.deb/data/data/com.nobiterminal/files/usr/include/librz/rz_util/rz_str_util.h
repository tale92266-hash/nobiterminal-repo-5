#ifndef RZ_STR_UTIL_H
#define RZ_STR_UTIL_H

#define IS_NULLSTR(x)   (!(x) || !*(x))
#define IS_WHITECHAR(x) ((x) == ' ' || (x) == '\t' || (x) == '\n' || (x) == '\r')
#define IS_SEPARATOR(x) ((x) == ' ' || (x) == '\t' || (x) == '\n' || (x) == '\r' || (x) == ' ' || \
	(x) == ',' || (x) == ';' || (x) == ':' || (x) == '[' || (x) == ']' || \
	(x) == '(' || (x) == ')' || (x) == '{' || (x) == '}')
#define IS_HEXCHAR(x)     (((x) >= '0' && (x) <= '9') || ((x) >= 'a' && (x) <= 'f') || ((x) >= 'A' && (x) <= 'F'))
#define IS_PRINTABLE(x)   ((x) >= ' ' && (x) <= '~')
#define IS_DIGIT(x)       ((x) >= '0' && (x) <= '9')
#define IS_OCTAL(x)       ((x) >= '0' && (x) <= '7')
#define IS_WHITESPACE(x)  ((x) == ' ' || (x) == '\t')
#define IS_UPPER(c)       ((c) >= 'A' && (c) <= 'Z')
#define IS_LOWER(c)       ((c) >= 'a' && (c) <= 'z')
#define IS_ALPHA(c)       (IS_LOWER(c) || IS_UPPER(c))
#define IS_ALPHANUM(c)    (IS_DIGIT(c) || IS_UPPER(c) || IS_LOWER(c))
#define IS_PARANTHESIS(c) ((c) == '(' || (c) == ')')

#endif //  RZ_STR_UTIL_H
