/**
 * PANDA 3D SOFTWARE
 * Copyright (c) Carnegie Mellon University.  All rights reserved.
 *
 * All use of this software is subject to the terms of the revised BSD
 * license.  You should have received a copy of this license along
 * with this source code in a file named "LICENSE."
 *
 * @file config_gsgbase.h
 * @author drose
 * @date 1999-10-06
 */

#ifndef CONFIG_GSGBASE_H
#define CONFIG_GSGBASE_H

// No config variables to define yet for this package.

#endif
