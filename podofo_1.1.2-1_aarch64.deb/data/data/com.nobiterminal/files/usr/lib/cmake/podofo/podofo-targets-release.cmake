#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "podofo::podofo_shared" for configuration "Release"
set_property(TARGET podofo::podofo_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(podofo::podofo_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libpodofo.so"
  IMPORTED_SONAME_RELEASE "libpodofo.so"
  )

list(APPEND _cmake_import_check_targets podofo::podofo_shared )
list(APPEND _cmake_import_check_files_for_podofo::podofo_shared "/data/data/com.nobiterminal/files/usr/lib/libpodofo.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
