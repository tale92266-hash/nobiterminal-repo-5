#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qpdf::libqpdf" for configuration "Release"
set_property(TARGET qpdf::libqpdf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(qpdf::libqpdf PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libqpdf.so"
  IMPORTED_SONAME_RELEASE "libqpdf.so"
  )

list(APPEND _cmake_import_check_targets qpdf::libqpdf )
list(APPEND _cmake_import_check_files_for_qpdf::libqpdf "/data/data/com.nobiterminal/files/usr/lib/libqpdf.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
