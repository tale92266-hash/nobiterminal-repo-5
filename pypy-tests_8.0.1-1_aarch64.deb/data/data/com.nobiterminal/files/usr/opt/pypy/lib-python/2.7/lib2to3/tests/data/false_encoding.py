#!/data/data/com.nobiterminal/files/usr/bin/env python
print '#coding=0'
