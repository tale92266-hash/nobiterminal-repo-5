#!/data/data/com.nobiterminal/files/usr/bin/bash
#
#   source_date_epoch.sh - handle SOURCE_DATE_EPOCH variable for reproducibility
#
#   Copyright (c) 2017-2025 Pacman Development Team <pacman-dev@lists.archlinux.org>
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

[[ -n "$LIBMAKEPKG_REPRODUCIBLE_SOURCE_DATE_EPOCH_SH" ]] && return
LIBMAKEPKG_REPRODUCIBLE_SOURCE_DATE_EPOCH_SH=1


MAKEPKG_LIBRARY=${MAKEPKG_LIBRARY:-'/data/data/com.nobiterminal/files/usr/share/makepkg'}


if [[ -n $SOURCE_DATE_EPOCH ]]; then
	REPRODUCIBLE=1
else
	SOURCE_DATE_EPOCH=$(date +%s)
fi
export SOURCE_DATE_EPOCH
